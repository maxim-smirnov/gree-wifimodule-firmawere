#!/bin/sh

name_prefix="gree_hc_"
app_path="/data/homeassistant/"
linux_cmd="cmd-linux-arm"
demo_gree="demo_gree"
can="iot_host_can"
third_party="third_party"
# air="airsys.sh"
test="test"

cmd_ps="ps -ef"
cmd_grep="grep -w"
cmd_awk_row="awk '{print \$2}'"
cmd_count="wc -l"

retry_times=0

count_all_pid="ps -ef |  awk '/gree_hc/ {print}'| awk '{print $2}' | wc -l"
count_linux_cmd="${cmd_ps} | ${cmd_grep} \"${app_path}${name_prefix}${linux_cmd}\" | ${cmd_count}"
count_demo_gree="${cmd_ps} | ${cmd_grep} \"${app_path}${name_prefix}${demo_gree}\" | ${cmd_count}"
count_can="${cmd_ps} | ${cmd_grep} \"${app_path}${name_prefix}${can}\" | ${cmd_count}"
count_test="${cmd_ps} | ${cmd_grep} \"${app_path}${name_prefix}${test}\" | ${cmd_count}"

echo "deamon is running..."
echo "${count_linux_cmd}"
echo "${count_demo_gree}"
echo "${count_can}"
echo "${count_test}"

sleep 10
while :
do
        linux_num=$(${cmd_ps} | ${cmd_grep} "${app_path}${name_prefix}${linux_cmd}" | ${cmd_count})
	echo "check linux cmd num is $linux_num"
        gree_num=$(${cmd_ps} | ${cmd_grep} "${app_path}${name_prefix}${demo_gree}" | ${cmd_count})
	echo "check demo gree num is $gree_num"
        can_num=$(${cmd_ps} | ${cmd_grep} "${app_path}${name_prefix}${can}" |  ${cmd_count})
	echo "can num is $can_num"
        test_num=$(${cmd_ps} | ${cmd_grep} "${app_path}${name_prefix}${test}" |  ${cmd_count})
	echo "test num is $test_num"

	# air_num=$(${cmd_ps} | ${cmd_grep} "${app_path}${name_prefix}${air}" |  ${cmd_count})
	# echo "air num is $air_num"
	
        third_num=$(${cmd_ps} | ${cmd_grep} "${app_path}${name_prefix}${third_party}" |  ${cmd_count})
	echo "third num is $third_num"

        #confirm the running pid count
        if [ $linux_num -ne 2 ] || [ $gree_num -ne 2 ] || [ $can_num -ne 2 ] || [ $test_num -ne 2 ]|| [ $third_num -ne 2 ];
        then
                echo "the exe is loss,retry it in [$retry_times] times!"

                linux_info=$(${cmd_ps} | ${cmd_grep} "${app_path}${name_prefix}${linux_cmd}" )
                echo "$linux_info"
                echo " "
                gree_info=$(${cmd_ps} | ${cmd_grep} "${app_path}${name_prefix}${demo_gree}" )
                echo "$gree_info"
                echo " "
                can_info=$(${cmd_ps} | ${cmd_grep} "${app_path}${name_prefix}${can}" )
                echo "$can_info"
                echo " "
                test_info=$(${cmd_ps} | ${cmd_grep} "${app_path}${name_prefix}${test}" )
                echo "$test_info"
                echo " "
                # air_info=$(${cmd_ps} | ${cmd_grep} "${app_path}${name_prefix}${air}" )
                # echo "$air_info"
                # echo " "
                third_info=$(${cmd_ps} | ${cmd_grep} "${app_path}${name_prefix}${third_party}" )
                echo "$third_info"
                echo " "
                

                linux_num=$(${cmd_ps} | ${cmd_grep} "${app_path}${name_prefix}${linux_cmd}" | ${cmd_count})
                echo "comfirm linux_cmd num is $linux_num"
                gree_num=$(${cmd_ps} | ${cmd_grep} "${app_path}${name_prefix}${demo_gree}" | ${cmd_count})
                echo "comfirm retry demo_gree num is $gree_num"
                can_num=$(${cmd_ps} | ${cmd_grep} "${app_path}${name_prefix}${can}" |  ${cmd_count})
                echo "comfirm retry iot_can num is $can_num"
                test_num=$(${cmd_ps} | ${cmd_grep} "${app_path}${name_prefix}${test}" |  ${cmd_count})
	        echo "test num is $test_num"
                # air_num=$(${cmd_ps} | ${cmd_grep} "${app_path}${name_prefix}${air}" |  ${cmd_count})
	        # echo "comfirm air num is $air_num"
                third_num=$(${cmd_ps} | ${cmd_grep} "${app_path}${name_prefix}${third_party}" |  ${cmd_count})
	        echo "comfirm third num is $third_num"

                retry_times=$(($retry_times + 1))
                if [ $retry_times -gt 5 ];
                then
                        echo "the exe loss,retry 5 times,will reboot now!"
                        date >> /home/root/data/host_system_log
                        echo "the count result is cmd:$linux_num;gree:$gree_num;can:$can_num;test:$test_num;third:$third_num" >> /home/root/data/host_system_log

                        killall gree_hc_iot_host_can
                        killall gree_hc_demo_gree
                        killall gree_hc_cmd-linux-arm
                        killall gree_hc_test
                        # killall gree_hc_airsys.sh
                        killall gree_hc_third_party
                        killall udhcpc
                        sh /data/homeassistant/gree_hc_ota  start
                else
                        sleep 1
                        continue
                fi
                
        fi

        retry_times=0

        size=$(du -m /data/homeassistant/logs | awk '{print $1}')
        echo 'log size is' $size
        if [ $size -gt 500 ]
        then
        	echo "" > /data/homeassistant/logs/gree_hc_cmd-linux-arm.log
                echo "" > /data/homeassistant/logs/gree_hc_ota.log
                echo "" > /data/homeassistant/logs/gree_hc_iot_host_can.log
                echo "" > /data/homeassistant/logs/gree_hc_daemon.log
                echo "" > /data/homeassistant/logs/gree_hc_test.log
                echo "" > /data/homeassistant/logs/gree_hc_demo_gree.log
                echo "" > /data/homeassistant/logs/homeassistant.log
                echo "" > /data/homeassistant/logs/gree_hc_third_party.log
	fi
        sleep   15
done

~                                                                                                                                                                                    
