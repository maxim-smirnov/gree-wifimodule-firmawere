#!/system/bin/sh
/system/bin/uni_netm > /dev/ttyFIQ0 &
tinymix -D 1 0 16
tinymix -D 1 1 16

echo d > /sys/rk322x-codec/rk3229-ctl
echo e > /sys/rk322x-codec/rk3229-ctl
echo 20 > /sys/class/gpio/export
echo out > /sys/class/gpio/gpio20/direction
echo 1 > /sys/class/gpio/gpio20/value
echo 27 > /sys/class/gpio/export
echo out > /sys/class/gpio/gpio27/direction
echo 1 > /sys/class/gpio/gpio27/value
echo 111 > /sys/class/gpio/export
echo out > /sys/class/gpio/gpio111/direction
echo 1 > /sys/class/gpio/gpio111/value

echo t > /sys/rk322x-codec/rk3229-ctl
tinyplay1 /system/bin/10000.wav -D 1
echo 0 > /sys/class/gpio/gpio27/value
echo 1 > /sys/class/gpio/gpio27/value


/data/led_test > /dev/ttyFIQ0 &
/data/uni_test > /dev/ttyFIQ0 &

PWD=$(cd $(busybox dirname $0) && pwd)
echo 1       1       1      1 > /proc/sys/kernel/printk &
ulimit -c unlimited
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:${PWD}/lib
if [ -e "${PWD}/debug_open" ]; then
  echo "start tail asr log"
  echo "" > ${PWD}/asr_log
  busybox tail -f ${PWD}/asr_log > /dev/ttyFIQ0 &
fi
echo "" > /data/init_file
while [ 1 ];
do
  cd $PWD && ./uni_demo > /dev/ttyFIQ0
done

