#!/bin/sh

name_prefix="gree_hc_"
linux_cmd="cmd-linux-arm"
demo_gree="demo_gree"
can="iot_host_can"

cmd_ps="ps -ef"
cmd_awk_row="awk '{print \$2}'"
cmd_count="wc -l"

count_all_pid="ps -ef |  awk '/gree_hc/ {print}'| awk '{print $2}' | wc -l"
count_linux_cmd="${cmd_ps} | awk '/${name_prefix}${linux_cmd}/ {print}'| ${cmd_awk_row} | ${cmd_count}"
count_demo_gree="${cmd_ps} | awk '/${name_prefix}${demo_gree}/ {print}'| ${cmd_awk_row} | ${cmd_count}"
count_can="${cmd_ps} | awk '/${name_prefix}${can}/ {print}'| ${cmd_awk_row} | ${cmd_count}"

echo "deamon is running..."
echo "${count_linux_cmd}"
echo "${count_demo_gree}"
echo "${count_can}"

sleep 10
while :
do
       #linux_num=$("${count_linux_cmd}")
        linux_num=$(ps -ef | awk '/gree_hc_cmd-linux-arm/ {print}'| awk '{print $2}' | wc -l)
	echo "linux cmd num is $linux_num"
        #gree_num=$("${count_demo_gree}")
        gree_num=$(ps -ef | awk '/gree_hc_demo_gree/ {print}'| awk '{print $2}' | wc -l)
	echo "demo gree num is $gree_num"
        #can_num=$("${count_can}")
        can_num=$(ps -ef | awk '/gree_hc_iot_host_can/ {print}'| awk '{print $2}' | wc -l)
	echo "can num is $can_num"
	
	#tail -f check
	tail_linux_num=$(ps -ef | awk '/tail -f gree_hc_cmd-linux-arm/ {print}'| awk '{print $2}' | wc -l)
	tail_gree_num=$(ps -ef | awk '/tail -f gree_hc_demo_gree/ {print}'| awk '{print $2}' | wc -l)
	tail_can_num=$(ps -ef | awk '/tail -f gree_hc_iot_host_can/ {print}'| awk '{print $2}' | wc -l)
	if [ $tail_linux_num -gt 1 ];
	then
		linux_num=$(expr $linux_num - $tail_linux_num + 1)
		echo "filted tail -f linux number is $linux_num"
	fi
	if [ $tail_gree_num -gt 1 ];
        then
		gree_num=$(expr $gree_num - $tail_gree_num + 1)
		echo "filted tail -f gree number is $gree_num"
        fi
	if [ $tail_can_num -gt 1 ];
        then
		can_num=$(expr $can_num - $tail_can_num + 1)
		echo "filted tail -f can number is $can_num"
        fi

	#confirm the running pid count
        if [ $linux_num -ne 2 ] || [ $gree_num -ne 2 ] || [ $can_num -ne 2 ];
        then
                echo "the exe is less than 5,will reboot now!"
		date >> /home/root/data/host_system_log
		echo "the count result is cmd:$linux_num;gree:$gree_num;can:$can_num" >> /home/root/data/host_system_log
                killall gree_hc_iot_host_can
                killall gree_hc_demo_gree
                killall gree_hc_cmd-linux-arm
		killall gree_hc_test
                killall udhcpc
                sh /data/homeassistant/gree_hc_ota  start
        fi
        size=$(du -m /data/homeassistant/logs | awk '{print $1}')
        echo 'log size is' $size
        if [ $size -gt 500 ]
        then
        	echo "" > /data/homeassistant/logs/gree_hc_cmd-linux-arm.log
                echo "" > /data/homeassistant/logs/gree_hc_ota.log
                echo "" > /data/homeassistant/logs/iot_host_can.log
                echo "" > /data/homeassistant/logs/gree_hc_daemon.log
                echo "" > /data/homeassistant/logs/gree_hc_test.log
                echo "" > /data/homeassistant/logs/gree_hc_demo_gree.log
                echo "" > /data/homeassistant/logs/homeassistant.log
	fi
        sleep   15
done

~                                                                                                                                                                                    
